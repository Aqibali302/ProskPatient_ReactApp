export const properties = {
  url: "http://34.226.145.23:8080",
};
