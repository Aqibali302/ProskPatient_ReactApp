import React from "react";
import {
  Grid,
  Card,
  CardHeader,
  IconButton,
  CardContent,
  Typography,
  Avatar,
  Stepper,
  Step,
  StepButton,
  Divider,
  Button,
} from "@material-ui/core";
import { spacing } from "@material-ui/system";
import BottomNavigation from "@material-ui/core/BottomNavigation";
import BottomNavigationAction from "@material-ui/core/BottomNavigationAction";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import HomeIcon from "@material-ui/icons/Home";
import BottomBar from "./BottomBar";
import { green } from "@material-ui/core/colors";
import { makeStyles, withStyles } from "@material-ui/styles";
import TextField from "@material-ui/core/TextField";
import Box from "@material-ui/core/Box";
import { Line, Circle } from 'rc-progress';
import ProgressBar from 'react-animated-progress-bar';
import SkipPreviousIcon from '@material-ui/icons/SkipPrevious';
import SkipNextIcon from '@material-ui/icons/SkipNext';
import DoneIcon from '@material-ui/icons/Done';
import * as moment from "moment";
import { properties } from "./properties";
import {
  DatePicker,
  TimePicker,
  MuiPickersUtilsProvider,
} from "material-ui-pickers";
import DateFnsUtils from "@date-io/date-fns";
import Checkbox from "@material-ui/core/Checkbox";


const useStyles = (theme) => ({
  root: {
    flexGrow: 1,
  },
  grow: {
    flexGrow: 1,
  },
  menuButton: {
    marginLeft: -12,
    marginRight: 20,
  },
  title: {
    display: "none",
  },

  sectionDesktop: {
    display: "none",
  },
  sectionMobile: {
    display: "flex",
  },
  bigAvatar: {
    margin: 10,
  },
  inline: {
    display: "inline",
  },
  iconSmall: {
    fontSize: 20,
  },
  card: {
    marginLeft: "10px",
    marginRight: "10px",
    marginTop: "10px",
  },
});

const classes = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
  },
  grow: {
    flexGrow: 1,
  },
  menuButton: {
    marginLeft: -12,
    marginRight: 20,
  },
  title: {
    display: "none",
  },

  sectionDesktop: {
    display: "none",
  },
  sectionMobile: {
    display: "flex",
  },
  bigAvatar: {
    margin: 10,
  },

  inline: {
    display: "inline",
  },
  card: {
    marginLeft: "10px",
    marginRight: "10px",
    marginTop: "10px",
  },
}));

class Consent2 extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      PatientID:localStorage.getItem("PID"),
      appointment_id: localStorage.getItem("AppointmentID"),
      date_of_birth: localStorage.getItem("date_of_birth"),
      first_name: localStorage.getItem("first_name"),
      middle_name: localStorage.getItem("middle_name"),
      last_name: localStorage.getItem("last_name"),
    };
    localStorage.setItem("url", properties.url);
  }

   SkipForm= (event) => {
    window.location = "#/Consent3";
  }
  
   PrevisousForm= (event) => {
    window.location = "#/Consent1";
  }
first_name = (event) => {
    this.setState({
      first_name: event.target.value,
    });
  };
middle_name = (event) => {
    this.setState({
      middle_name: event.target.value,
    });
  };
  last_name = (event) => {
    this.setState({
      last_name: event.target.value,
    });
  };
handleDateOfBirthChangeFrom = (event) => {
    this.setState({ date_of_birth: event });
  };
  

submitForm(event) {
    document.getElementById("submit-button").click();
  };
  handleSubmit(event, state) {
    event.preventDefault();
    const Formitteddatofbirth = moment(this.state.date_of_birth).format(
      "MM/DD/YYYY"
    );

    let url =
      localStorage.getItem("url") +
      "/MobileSaveAuthorizationComplianceV2?FName=" +
      this.state.first_name +
      "&PID=" +
      this.state.PatientID +
      "&LName=" +
      this.state.last_name +
      "&MName=" +
      this.state.middle_name +
      "&DOB=" +
      Formitteddatofbirth ;
    fetch(url, {
      method: "POST",
      // body: JSON.stringify(data),
    })
      .then((res) => {
        if (!res.ok) {
          throw res;
        }
        return res.json();
      })
      .then((result) => {
        if (result["success"] == "1") {
          window.location = "#/Consent3/";
        } else {
          alert(result["error_message"]);
        }
      })
      .catch((error) => alert("An error occured: " + error));
  }
keyPress(e) {
    if (e.keyCode == 13) {
      e.preventDefault();
    }
  }
  StopEnter(e) {
    if (e.keyCode == 13) {
      e.preventDefault();
    }
  }
   handleMenu = (event) => {
    window.location = "#/home/";
  };
  render() {
    const { classes } = this.props;

  return (
    <div className={classes.root}>
      <form
          onKeyPress={this.StopEnter}
          onSubmit={(event) => this.handleSubmit(event, this.state)}
          autoComplete="off"
        >
      <AppBar position="fixed">
        <Toolbar variant="dense">
          {/* <IconButton color="inherit" aria-label="Menu">
            <img src={logo1} width={30} />
          </IconButton> */}
          <Typography
            variant="h6"
            color="inherit"
            noWrap
            style={{textAlign:"center"}}
          >
            Prosk™
          </Typography>
          <div className={classes.grow}/>
          <Typography
            variant="h6"
            color="inherit"
            noWrap
            style={{textAlign:"center"}}
          >
            Authorization
          </Typography>
          <div className={classes.grow}/>
          <div>
            <IconButton color="inherit" onClick={this.handleMenu}>
              <HomeIcon /><Typography
              color="inherit"
              noWrap
            >
              Home
            </Typography>
            </IconButton>
          </div>
        </Toolbar>
      </AppBar>
      <div style={{ marginTop: "60px" }}>
        <Card style={{ width: "98%",margin:"auto" }}>
         
            <CardContent>
              <Grid container spacing={8}>
                <Grid item xs={12} align="center">
                  <Typography variant="title" color="primary"></Typography>
                </Grid>
                <Grid item xs={12} align="left">
                  <Typography
                    variant="title"
                    style={{
                      marginBottom: "10px",
                      fontSize: "20px",
                      fontFamily: "initial",
                      fontWeight: "bolder",
                    }}
                  >
                    Authorization for Compliance with the Virginia Prescription
                    Monitoring Program
                  </Typography>
                </Grid>
                <Grid item xs={12} sm={3}>
                  <TextField
                    // onKeyDown={this.StopEnter}
                    //id="remarks"
                    name="PatientName"
                    label="Patient Name"
                    style={{ width: "95%", height: "5%" }}
                    className={classes.textFieldCard}
                     onChange={this.first_name}
                    // margin="normal"
                    // error={this.state.remarks}
                     value={this.state.first_name}
                    //helperText={this.state.remarks_error}
                    required
                  />
                </Grid>
                <Grid item xs={12} sm={3}>
                  <TextField
                    // onKeyDown={this.StopEnter}
                    //id="remarks"
                    name="MiddleName"
                    label="Middle Name"
                    // className={classes.textFieldCard}
                     onChange={this.middle_name}
                    // margin="normal"
                    // error={this.state.remarks}
                     value={this.state.middle_name}
                    //helperText={this.state.remarks_error}
                   // required
                    style={{ width: "95%", height: "5%" }}
                  />
                </Grid>
               
                <Grid item xs={12} sm={3}>
                  <TextField
                    // onKeyDown={this.StopEnter}
                    //id="remarks"
                    name="LastName"
                    label="Last Name"
                    // className={classes.textFieldCard}
                     onChange={this.last_name}
                    // margin="normal"
                    // error={this.state.remarks}
                     value={this.state.last_name}
                    //helperText={this.state.remarks_error}
                    required
                    style={{ width: "95%", height: "5%" }}
                  />
                </Grid>
                 <Grid item xs={12} sm={3}>
                <MuiPickersUtilsProvider utils={DateFnsUtils}>
                        <DatePicker
                          keyboard
                          views={["year", "month", "day"]}
                          openTo={"year"}
                          format={"dd/MM/yyyy"}
                          placeholder="18/10/2019"
                          label="Date of Birth"
                          name="dateOfBirth"
                          id="date_of_birth"
                          // required
                          mask={(value) =>
                            // handle clearing outside if value can be changed outside of the component
                            value
                              ? [
                                  /\d/,
                                  /\d/,
                                  "/",
                                  /\d/,
                                  /\d/,
                                  "/",
                                  /\d/,
                                  /\d/,
                                  /\d/,
                                  /\d/,
                                ]
                              : []
                          }
                          disableOpenOnEnter
                          animateYearScrolling={false}
                          style={{ width: "90%" }}
                          onChange={this.handleDateOfBirthChangeFrom}
                          value={this.state.date_of_birth}
                        />
                      </MuiPickersUtilsProvider>
                </Grid>
                <Grid item xs={12} align="left">
                  <Typography
                    variant="title"
                    style={{
                      marginTop: "10px",
                      fontSize: "18px",
                      fontFamily: "initial",
                    }}
                  >
                    <p>
                      • I understand that CLINIC participates in the Virgina
                      Prescription Monitoring Program.
                    </p>
                  </Typography>
                  <Typography
                    variant="title"
                    style={{
                      marginTop: "10px",
                      fontSize: "18px",
                      fontFamily: "initial",
                    }}
                  >
                    • I give permission for CLINIC to access this database for
                    Prescription Compliance and consult with any other physician
                    prescribing controlled substances.This consent begins on the
                    data below and remains in effect unless revoked in writing.
                  </Typography>
                </Grid>
                <Grid item xs={12} align="left">
                  <Typography
                    variant="title"
                    style={{
                      marginTop: "5px",
                      fontSize: "20px",
                      fontFamily: "initial",
                      fontWeight: "bolder",
                    }}
                  >
                    Verginia Administrative Code (2013) 18VAC 76-20-70
                  </Typography>
                  <Typography
                    variant="title"
                    style={{
                      marginTop: "10px",
                      fontSize: "18px",
                      fontFamily: "initial",
                    }}
                  >
                    Title 18.Professional and Occupational Licensing Vac Agency
                    No.76.Department of Health Profession Chapter 20.Regulations
                    Government The Prescription Monitoring Program 18 VAC
                    76-20-70.Notice of request for information:
                  </Typography>
                  <Divider variant="middle" />
                  <Typography
                    variant="title"
                    style={{
                      marginTop: "10px",
                      fontSize: "18px",
                      fontFamily: "initial",
                    }}
                  >
                    𝐀. Any prescriber who intends to request information from
                    the program about a patient onprospective patient shall post
                    a sign that can be easily viewed by the public that disclose
                    to the public that the prescriber may access information
                    contained in the program files on all Schedule II,III or IV
                    Prescription dispened to a patient.In lien of posting a
                    sign,the in written material provide to the patient, or may
                    obtain written consent rom patient.
                  </Typography>
                  <Divider variant="middle" />
                  <Typography
                    variant="title"
                    style={{
                      marginTop: "10px",
                      fontSize: "18px",
                      fontFamily: "initial",
                    }}
                  >
                    𝗕. Any prescriber who intends to request information from
                    the program for a recipient or prospective recipient of a
                    Schedule II,III or IV controlled substance shall post a sign
                    that can be easily viewed by the public at the place where
                    the Prescription is accepted for dispensing and that
                    disclose to the public that the pharmacist may access
                    infomation contained in the program files on al Schedule
                    II,III or IV Prescription dispened to a patient.In lien of
                    posting a sign, that dispened may provide such notice in
                    written material provide to the recipient, or may obtain
                    written consent from the recipient. Prescription dispened to
                    a patient.In lien of posting a sign, that dispened may
                    provide such notice in written material provide to the
                    recipient, or may obtain written consent from the recipient.
                  </Typography>
                  <Divider variant="middle" />
                </Grid>
                
              </Grid>
            </CardContent>
        </Card>
        <div  style={{height:"60px"}}>
                  
                </div>
      </div>

      <AppBar
        position="fixed"
        style={{ top: "auto", bottom: 0 }}
        color="default"
      >
        <Toolbar variant="dense">
          <Button
            variant="contained"
            color="default"
            onClick={this.PrevisousForm}
          >
              <SkipPreviousIcon style={{marginRight:"1px"}} /> Back
          </Button>
          <div className={classes.grow} />
        <ProgressBar
        width="400px"
        height="16px"
        rect
        fontColor="gray"
        percentage="20"
        rectPadding="1px"
        rectBorderRadius="20px"
        trackPathColor="transparent"
        bgColor="primary"
        trackBorderColor="grey"
        defColor={{
          fair: 'teal',
          good: 'teal',
          excellent: 'teal',
          poor: 'teal',
        }}
      />
          <div className={classes.grow} />
          <Button
            variant="contained"
            color="defualt"
            onClick={this.SkipForm}
            style={{marginRight:"10px"}}
          >
            <SkipNextIcon style={{marginRight:"1px"}} />  Skip
          </Button>

          <Button
            variant="contained"
            color="primary"
            type="submit"
          >
          <DoneIcon style={{marginRight:"1px"}} />  Agree
          </Button>
        </Toolbar>
      </AppBar>
      
          </form>
    </div>
  );
}
}
export default withStyles(useStyles)(Consent2);
