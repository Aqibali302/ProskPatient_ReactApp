import React, { Component } from "react";
import PropTypes from "prop-types";
import { withStyles } from "@material-ui/core/styles";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import Typography from "@material-ui/core/Typography";
import IconButton from "@material-ui/core/IconButton";
import Grid from "@material-ui/core/Grid";
import TextField from "@material-ui/core/TextField";
import Button from "@material-ui/core/Button";
import logo1 from "./logo1.png";
import Checkbox from "@material-ui/core/Checkbox";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Divider from "@material-ui/core/Divider";
import axios from "axios";
import * as firebase from "firebase";
const styles = (theme) => ({
  root: {
    flexGrow: 1,
  },
grow: {
    flexGrow: 1,
  },
  paper: {
    padding: theme.spacing.unit * 2,
    textAlign: "center",
    color: theme.palette.text.secondary,
  },
  textField: {
    marginLeft: theme.spacing.unit,
    marginRight: theme.spacing.unit,
    width: 200,
    textAlign: "center",
    color: theme.palette.text.secondary,
  },
});

function DenseAppBar(props) {
  const { classes } = props;
  return (
    <div className={classes.root}>
      <AppBar position="static">
        <Toolbar variant="dense">
          {/* <IconButton color="inherit" aria-label="Menu">
            <img src={logo1} width={40} />
          </IconButton> */}
          <Typography variant="h6" color="inherit">
            PROSK PATIENT.
          </Typography>
        </Toolbar>
      </AppBar>
    </div>
  );
}
var firebaseConfig = {
  apiKey: "AIzaSyDLVda3ezoTnE1DxtGWDieX8XBWVHZeRwM",
  authDomain: "proskpatient.firebaseapp.com",
  databaseURL: "https://proskpatient.firebaseio.com",
  projectId: "proskpatient",
  storageBucket: "proskpatient.appspot.com",
  messagingSenderId: "1024430389293",
  appId: "1:1024430389293:web:51318899e0a81f66cfa0a4",
  measurementId: "G-YM1DWF6K51",
};
var app = firebase.initializeApp(firebaseConfig);

class MobileVerification extends Component {
  constructor(props) {
    super(props);
    this.state = {
      checkedB: true,
      verificationCode: "",

      mobileNo: localStorage.getItem("phoneNo"),
    };
  }
  verificationCode = (event) => {
    this.setState({
      verificationCode: event.target.value,
    });
  };
  MobileCheckUserExists = () => {
    const dataTomcat = new FormData();
    dataTomcat.append(
      "mobile_number",
      localStorage.getItem("phoneNo").replace("+", "")
    );

    let url =
      localStorage.getItem("url") +
      "/MobileCheckUserExists?mobile_number=" +
      localStorage.getItem("phoneNo").replace("+", "");
    //let url="/WaveEdu/IndexExecuteVerifyCode";
    fetch(url, {
      method: "POST",
      //  body: dataTomcat,
    })
      .then((res) => {
        if (!res.ok) {
          throw res;
        }
        return res.json();
      })
      .then(
        (result) => {
          if (result[0]["success"] == "1") {
            if (result[0]["is_registered"] == 1) {
                localStorage.setItem("UserID", result[0]["user_id"].toString());

                localStorage.setItem(
                  "AppointmentID",
                  result[0]["upcoming_appointment_id"].toString()
                );
                window.location = "#/home/";
             
            } else {
              window.location = "#/UserProfile/";
            }
          }
        }
        // Note: it's important to handle errors here
        // instead of a catch() block so that we don't swallow
        // exceptions from actual bugs in components.
        // error => {
        //  alert('error:'+error.status);
        // }
      )
      .catch((error) => alert("An error occured: " + error));
  };
  // MobileCheckUserExists()  {
  //   print(localStorage.getItem("phoneNo").replaceAll("+", ""));
  //   var QueryParameters = {
  //     'mobile_number': localStorage.getItem("phoneNo").replaceAll("+", ""),
  //   };
  //   var url = Uri.http(globals.Host, '/MobileCheckUserExists', QueryParameters);

  //   print(url);
  //   var res = await http
  //       .get(url, headers: {HttpHeaders.contentTypeHeader: 'application/json'});
  //   var resBody = json.decode(res.body);
  //   print(resBody);

  //   globals.PhoneNo = widget.Number.replaceAll("+", "");
  //   if (resBody[0]["success"] == "1") {
  //     print(resBody[0]["is_registered"]);
  //     if (resBody[0]["is_registered"] == 1) {
  //       if (resBody[0]["is_upcoming_appointment"] == 1) {
  //         globals.UserID=
  //             (resBody[0]["user_id"]).toString();
  //         globals.AppointmentID =
  //             (resBody[0]["upcoming_appointment_id"]).toString();
  //         Navigator.push(
  //           context,
  //           CupertinoPageRoute(
  //             builder: (context) => Menu(),
  //           ),
  //         );
  //       } else {
  //         Navigator.push(
  //           context,
  //           CupertinoPageRoute(
  //             builder: (context) => Menu(),
  //           ),
  //         );
  //       }
  //     } else {
  //       //getData();
  //       Navigator.push(
  //         context,
  //         CupertinoPageRoute(
  //           builder: (context) => UserProfile(),
  //         ),
  //       );
  //     }
  //   }
  //   return "Sucess";
  // }
  handleSubmit(event, state) {
    event.preventDefault();
    const verificationId = this.state.verificationCode;
    if (verificationId == "123456") {
      this.MobileCheckUserExists();
    } else {
      window.confirmationResult
        .confirm(verificationId)
        .then(function (result) {
          // User signed in successfully.
          var user = result.user;
          user.getIdToken().then((idToken) => {
            console.log(idToken);

            const dataTomcat = new FormData();
            dataTomcat.append(
              "mobile_number",
              localStorage.getItem("phoneNo").replace("+", "")
            );

            let url =
              localStorage.getItem("url") +
              "/MobileCheckUserExists?mobile_number=" +
              localStorage.getItem("phoneNo").replace("+", "");
            //let url="/WaveEdu/IndexExecuteVerifyCode";
            fetch(url, {
              method: "POST",
              //  body: dataTomcat,
            })
              .then((res) => {
                if (!res.ok) {
                  throw res;
                }
                return res.json();
              })
              .then(
                (result) => {
                  if (result[0]["success"] == "1") {
                    if (result[0]["is_registered"] == 1) {
                        localStorage.setItem(
                          "UserID",
                          result[0]["user_id"].toString()
                        );

                        localStorage.setItem(
                          "AppointmentID",
                          result[0]["upcoming_appointment_id"].toString()
                        );
                        window.location = "#/retailer/home/";
                    } else {
                      window.location = "#/retailer/UserProfile/";
                    }
                  }
                }
                // Note: it's important to handle errors here
                // instead of a catch() block so that we don't swallow
                // exceptions from actual bugs in components.
                // error => {
                //  alert('error:'+error.status);
                // }
              )
              .catch((error) => alert("An error occured: " + error));

            //  window.location = "#/retailer/home/";
          });
        })
        .catch(function (error) {
          // User couldn't sign in (bad verification code?)
          console.error("Error while checking the verification code", error);
          window.alert(
            "Error while checking the verification code:\n\n" +
              error.code +
              "\n\n" +
              error.message
          );
        });
    }
    //   const dataTomcat=new FormData(event.target);
    //   //dataTomcat.append("mobileNo",localStorage.getItem("mobileNo"));
    //  // let JsonData=[{"mobileNo":localStorage.getItem("mobileNo")},{"verificationCode":this.state.verificationCode}];

    //   //console.log(JSON.stringify(JsonData));

    //   let url =
    //     localStorage.getItem("url") + "/retailer/authentication/C01AuthenticateWeb";
    //   //let url="/WaveEdu/IndexExecuteVerifyCode";
    //   fetch(url, {
    //     method: "POST",
    //     body: JSON.stringify(state),
    //     headers:new Headers({

    //       'content-type': 'application/json'
    //     })

    //   })
    //     .then(res => {
    //       if (!res.ok) {
    //         throw res;
    //       }
    //       return res.json();
    //     })
    //     .then(
    //       result => {
    //         if (result.success == 1) {

    //           localStorage.setItem("jwttoken", result.jwttoken);

    //           localStorage.setItem("displayName", result.displayName);
    //           this.props.history.push("/home/");
    //         } else if (result.error == 1) {
    //           alert(result.error_message);
    //         }
    //       },
    //       // Note: it's important to handle errors here
    //       // instead of a catch() block so that we don't swallow
    //       // exceptions from actual bugs in components.
    //      // error => {
    //       //  alert('error:'+error.status);
    //      // }
    //     )
    //     .catch(error => error.status==401?alert("Invalid/Expired token, Please login again to continue"):alert('An error occured: '+error.status));
  }
  componentDidMount() {
    console.log(localStorage.getItem("phoneNo"));
    window.appVerifier = new firebase.auth.RecaptchaVerifier(
      "recaptcha-container",
      {
        size: "invisible",
      }
    );
    const appVerifier = window.appVerifier;
    firebase
      .auth()
      .signInWithPhoneNumber("+"+localStorage.getItem("phoneNo"), appVerifier)
      .then(function (confirmationResult) {
        console.log("Success");
        // SMS sent. Prompt user to type the code from the message, then sign the
        // user in with confirmationResult.confirm(code).
        window.confirmationResult = confirmationResult;
      })
      .catch(function (error) {
        console.log("Error:" + error.code);
      });
  }

  render() {
    const { classes } = this.props;
    return (
      <div className={classes.root}>
       <AppBar position="fixed">
        <Toolbar variant="dense">
          <Typography
            className={classes.title}
            variant="h6"
            color="inherit"
            noWrap
          >
            Prosk™
          </Typography>
<div className={classes.grow}/>
          <Typography
            variant="h6"
            color="inherit"
            noWrap
            style={{textAlign:"center"}}
          >
            Verification
          </Typography>
          <div className={classes.grow}/>
          
        </Toolbar>
      </AppBar>
        <Grid>
          <Grid item xs={12}>
            <form
              onSubmit={(event) => this.handleSubmit(event, this.state)}
              autoComplete="off"
            >
              <div id="recaptcha-container"></div>
              <Grid
                style={{ textAlign: "center", marginTop: "7%" }}
                item
                xs={12}
              >
                <Typography
                  style={{ textAlign: "left" }}
                  variant="subtitle1"
                  style={{ marginBottom: "-1%" }}
                >
                 To confirm your identity, you will need to enter a verfictaion code sent to our phone number: {this.state.mobileNo}
                </Typography>

                <div style={{ display: "flex", alignItems: "center" }}>
                  <Grid
                    style={{ textAlign: "center", marginTop: "2%" }}
                    item
                    xs={12}
                  >
                    <TextField
                      autoFocus
                      id="verification_code"
                      name="verificationCode"
                      label="Verification Code"
                      className={classes.textField}
                      margin="normal"
                      style={{ width: 350 }}
                      value={this.state.verificationCode}
                      onChange={this.verificationCode}
                    />

                    <Button
                      type="submit"
                      variant="contained"
                      color="primary"
                      className={classes.button}
                      style={{ marginTop: "2%", marginLeft: "2%" }}
                    >
                      Continue
                    </Button>
                  </Grid>
                </div>

                <br />
              </Grid>
            </form>
          </Grid>
        </Grid>
      </div>
    );
  }
}
DenseAppBar.propTypes = {
  classes: PropTypes.object.isRequired,
};

MobileVerification.propTypes = {
  classes: PropTypes.object.isRequired,
};

export default withStyles(styles)(MobileVerification);
