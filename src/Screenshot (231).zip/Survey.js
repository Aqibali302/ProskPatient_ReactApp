import React from "react";
import {
  Grid,
  Card,
  CardHeader,
  IconButton,
  CardContent,
  Typography,
  Avatar,
  Stepper,
  Step,
  StepButton,
  Button,
} from "@material-ui/core";
import BottomNavigation from "@material-ui/core/BottomNavigation";
import BottomNavigationAction from "@material-ui/core/BottomNavigationAction";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import HomeIcon from "@material-ui/icons/Home";
import BottomBar from "./BottomBar";
import * as moment from "moment";
import { green } from "@material-ui/core/colors";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import { makeStyles, withStyles } from "@material-ui/styles";
import TextField from "@material-ui/core/TextField";
import CheckBoxIcon from "@material-ui/icons/CheckBox";
import CheckBoxOutlineBlankIcon from "@material-ui/icons/CheckBoxOutlineBlank";
import Progress from "react-progressbar";
import { Line, Circle } from "rc-progress";
import ProgressBar from "react-animated-progress-bar";
import SkipPreviousIcon from "@material-ui/icons/SkipPrevious";
import SkipNextIcon from "@material-ui/icons/SkipNext";
import DoneIcon from "@material-ui/icons/Done";
import { properties } from "./properties";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";

import FormControl from "@material-ui/core/FormControl";
import FormLabel from "@material-ui/core/FormLabel";
import {
  DatePicker,
  TimePicker,
  MuiPickersUtilsProvider,
} from "material-ui-pickers";
import DateFnsUtils from "@date-io/date-fns";
import Checkbox from "@material-ui/core/Checkbox";

const useStyles = (theme) => ({
  root: {
    flexGrow: 1,
  },
  grow: {
    flexGrow: 1,
  },
  menuButton: {
    marginLeft: -12,
    marginRight: 20,
  },
  title: {
    display: "none",
  },

  sectionDesktop: {
    display: "none",
  },
  sectionMobile: {
    display: "flex",
  },
  bigAvatar: {
    margin: 10,
  },
  inline: {
    display: "inline",
  },
  iconSmall: {
    fontSize: 20,
  },
  card: {
    marginLeft: "10px",
    marginRight: "10px",
    marginTop: "10px",
  },
});

const classes = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
  },
  grow: {
    flexGrow: 1,
  },
  menuButton: {
    marginLeft: -12,
    marginRight: 20,
  },
  title: {
    display: "none",
  },

  sectionDesktop: {
    display: "none",
  },
  sectionMobile: {
    display: "flex",
  },
  bigAvatar: {
    margin: 10,
  },

  inline: {
    display: "inline",
  },
  card: {
    marginLeft: "10px",
    marginRight: "10px",
    marginTop: "10px",
  },
}));
class Survey extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      PatientID: localStorage.getItem("PID"),
      appointmentID: localStorage.getItem("AppointmentID"),
      QuestionIndex: 0,
      feet: "",
      inches: "",
      meters: "",
      kg: "",
      pounds: "",
      AnswerID: "-1",
      AnswerValue: "-1",
      selectedRadioValue: "Imperial",
      selectedWeightRadioValue: "Metric",
      Title: " ",
      QuestionList: [],
      AnswerList: [],

      selectedAnswerRadioValue: "",
    };
    localStorage.setItem("url", properties.url);
  }

  feet = (event) => {
    this.setState({
      feet: !this.state.check_mobile,
    });
  };

  inches = (event) => {
    this.setState({
      inches: !this.state.check_email,
    });
  };
  meters = (event) => {
    this.setState({
      meters: event.target.value,
    });
  };

  kg = (event) => {
    this.setState({
      kg: event.target.value,
    });
  };
  pounds = (event) => {
    this.setState({
      pounds: event.target.value,
    });
  };
  handleWeightRadioChange = (event) => {
    if (this.state.selectedWeightRadioValue == "Imperial") {
      this.setState({
        selectedWeightRadioValue: "Metric",
      });
    } else if (this.state.selectedWeightRadioValue == "Metric")
      this.setState({
        selectedWeightRadioValue: "Imperial",
      });
  };
  handleRadioChange = (event) => {
    if (this.state.selectedRadioValue == "Imperial") {
      this.setState({
        selectedRadioValue: "Metric",
      });
    } else if (this.state.selectedRadioValue == "Metric")
      this.setState({
        selectedRadioValue: "Imperial",
      });
  };
  handleAnswerRadioChange = (event, AnswerRadioValue, answer_id) => {
    console.log(AnswerRadioValue);
    console.log(answer_id);
    console.log(AnswerRadioValue);
    this.setState({
      selectedAnswerRadioValue: AnswerRadioValue,
      AnswerID: answer_id,
      AnswerValue: AnswerRadioValue,
    });
    this.NextForm(event);
  };

  componentDidMount() {
    this.setState({
      QuestionList: [
        {
          question_no: "180",
          question_text: "In order to continue, you will need to know:",
          survey_type: "NewBackAndNeckPain",
          asset_name:
            "http://34.226.145.23:8080/images/undraw_medical_care_movn.png",
          type_id: 7,
        },
      ],
      AnswerList: [
        {
          answer_value: "1",
          answer_choice: "-  Your weight in either pounds or kilograms.",
          id: "2548",
        },
        {
          answer_value: "2",
          answer_choice: " -  Your height in either feet and inches or metres",
          id: "2683",
        },
        {
          answer_value: "3",
          answer_choice: "-  Your age in years",
          id: "2684",
        },
        {
          answer_value: "4",
          answer_choice:
            "-  Wheather you are considering a knee or hip joint replacement",
          id: "2685",
        },
      ],
    });
  }
  SkipForm() {
    window.location = "#/Consent2";
  }

  NextForm(event) {
    event.preventDefault();
    this.state.QuestionIndex++;
    if (this.state.AnswerID == "") {
      this.setState({
        AnswerID: "-1",
        AnswerValue: "-1",
      });
    }

    let url =
      localStorage.getItem("url") +
      "/MobileSaveSurveyAnswerv2?appointment_id=" +
      this.state.appointmentID +
      "&question_id=" +
      this.state.QuestionList[0]["question_no"].toString() +
      "&answer_id=" +
      this.state.AnswerID +
      "&answer_value=" +
      this.state.AnswerValue +
      "&survey_type=" +
      this.state.QuestionList[0]["survey_type"].toString() +
      "&type_id=" +
      this.state.QuestionList[0]["type_id"].toString() +
      "&kg=" +
      this.state.kg +
      "&feet=" +
      this.state.feet +
      "&inches=" +
      this.state.inches +
      "&meters=" +
      this.state.meters +
      "&pound=" +
      this.state.pounds;

    fetch(url, {
      method: "POST",
      // body: JSON.stringify(data),
    })
      .then((res) => {
        if (!res.ok) {
          throw res;
        }
        return res.json();
      })
      .then((result) => {
        if (result["success"] == "1") {
          if (result["next_question_id"] == "0") {
            window.location = "#/home/";
          } else {
            this.setState({
              AnswerID: "-1",
              AnswerValue: "-1",
              AnswerList: [],
              QuestionList: [
                {
                  question_no: result["next_question_id"],
                  question_text: result["question_text"],
                  survey_type: result["survey_type"],
                  type_id: result["type_id"],
                  asset_name: result["asset_name"],
                },
              ],
              feet: result["feet"].toString(),
              inches: result["inches"].toString(),
              meters: result["meters"].toString(),
              kg: result["kg"].toString(),
              pound: result["pounds"].toString(),
              Title: result["module_name"].toString(),
            });

            var Answers = result["answer_data"];
            let MyAnswerList = [];
            for (var i = 0; i < Answers.length; i++) {
              this.state.AnswerList.push({
                answer_value: Answers[i]["answer_value"],
                answer_choice: Answers[i]["answer_choice"],
                asset_name: Answers[i]["asset_name"],
                answer_id: Answers[i]["answer_id"],
              });
            }

            this.setState({
              AnswerList: this.state.AnswerList,
            });

            console.log(this.state.QuestionList);
            console.log(this.state.AnswerList);
            console.log(this.state.MyAnswerList);
          }
        } else {
          alert(result["error_message"]);
        }
      })
      .catch((error) => alert("An error occured: " + error));
  }

  BackForm(event) {
    event.preventDefault();
    this.state.QuestionIndex--;
    if (this.state.AnswerID == "") {
      this.setState({
        AnswerID: "-1",
        AnswerValue: "-1",
      });
    }

    let url =
      localStorage.getItem("url") +
      "/MobileGetPreviousSurveyAnswer?appointment_id=" +
      this.state.appointmentID +
      "&question_id=" +
      this.state.QuestionList[0]["question_no"].toString();

    fetch(url, {
      method: "POST",
      // body: JSON.stringify(data),
    })
      .then((res) => {
        if (!res.ok) {
          throw res;
        }
        return res.json();
      })
      .then((result) => {
        if (result["success"] == "1") {
          if (result["next_question_id"] == "0") {
            window.location = "#/home/";
          } else {
            this.setState({
              AnswerID: "-1",
              AnswerValue: "-1",
              AnswerList: [],
              QuestionList: [
                {
                  question_no: result["next_question_id"],
                  question_text: result["question_text"],
                  survey_type: result["survey_type"],
                  type_id: result["type_id"],
                  asset_name: result["asset_name"],
                },
              ],
              feet: result["feet"] + "",
              inches: result["inches"] + "",
              meters: result["meters"] + "",
              kg: result["kg"] + "",
              pound: result["pounds"] + "",
              Title: result["module_name"] + "",
            });

            var Answers = result["answer_data"];
            let MyAnswerList = [];
            for (var i = 0; i < Answers.length; i++) {
              this.state.AnswerList.push({
                answer_value: Answers[i]["answer_value"],
                answer_choice: Answers[i]["answer_choice"],
                asset_name: Answers[i]["asset_name"],
                answer_id: Answers[i]["answer_id"],
              });
            }

            this.setState({
              AnswerList: this.state.AnswerList,
            });

            console.log(this.state.QuestionList);
            console.log(this.state.AnswerList);
            console.log(this.state.MyAnswerList);
          }
        } else {
          alert(result["error_message"]);
        }
      })
      .catch((error) => alert("An error occured: " + error));
  }
  keyPress(e) {
    if (e.keyCode == 13) {
      e.preventDefault();
    }
  }
  StopEnter(e) {
    if (e.keyCode == 13) {
      e.preventDefault();
    }
  }
  handleMenu = (event) => {
    window.location = "#/home/";
  };
  render() {
    const { classes } = this.props;

    return (
      <div className={classes.root}>
        <form
          onKeyPress={this.StopEnter}
          onSubmit={(event) => this.handleSubmit(event, this.state)}
          autoComplete="off"
        >
          {" "}
          <Button
            type="submit"
            variant="contained"
            color="primary"
            id="submit-button"
            className={classes.button}
            style={{ display: "none" }}
          >
            submit
          </Button>
          <AppBar position="fixed">
            <Toolbar variant="dense">
              <Typography
                variant="h6"
                color="inherit"
                noWrap
                style={{ textAlign: "center" }}
              >
                Prosk™
              </Typography>
              <div className={classes.grow} />
              <Typography
                variant="h6"
                color="inherit"
                noWrap
                style={{ textAlign: "center" }}
              >
                {this.state.Title}
              </Typography>
              <div className={classes.grow} />
              <div>
                <IconButton color="inherit" onClick={this.handleMenu}>
                  <HomeIcon />
                  <Typography color="inherit" noWrap>
                    Home
                  </Typography>
                </IconButton>
              </div>
            </Toolbar>
          </AppBar>
          <div style={{ marginTop: "60px" }}>
            <Card style={{ width: "98%", margin: "auto" }}>
              <CardContent>
                {this.state.QuestionList.map((QuestionLists, idx) => (
                  <React.Fragment key={idx}>
                    <Grid container spacing={8}>
                      <Grid item xs={12} align="left">
                        <Typography
                          variant="title"
                          style={{
                            fontSize: "20px",
                            fontFamily: "initial",
                            fontWeight: "bolder",
                          }}
                        >
                          {QuestionLists.question_text}
                        </Typography>
                      </Grid>
                      {QuestionLists.type_id == 7 ? (
                        <Grid container>
                          {this.state.AnswerList.map((AnswerLists, idx) => (
                            <React.Fragment key={idx}>
                              <Grid item xs={12} align="left">
                                <Typography
                                  variant="title"
                                  style={{
                                    marginTop: "10px",
                                    fontSize: "18px",
                                    fontFamily: "initial",
                                  }}
                                >
                                  {AnswerLists.answer_choice}
                                </Typography>
                              </Grid>
                            </React.Fragment>
                          ))}
                        </Grid>
                      ) : (
                        <Grid container></Grid>
                      )}

                      {QuestionLists.type_id == 8 ? (
                        <Grid container>
                          <Grid item xs={12} align="left">
                            <FormControl component="fieldset">
                              <FormLabel component="legend">
                                {" "}
                                My measurement is in:
                              </FormLabel>
                              <RadioGroup
                                row
                                aria-label="position"
                                name="position"
                                defaultValue="top"
                              >
                                <FormControlLabel
                                  value="Imperial"
                                  control={
                                    <Radio
                                      checked={
                                        this.state.selectedRadioValue ==
                                        "Imperial"
                                      }
                                      onChange={this.handleRadioChange}
                                      color="primary"
                                    />
                                  }
                                  label="Imperial"
                                />
                                <FormControlLabel
                                  value="Metric"
                                  control={
                                    <Radio
                                      checked={
                                        this.state.selectedRadioValue ==
                                        "Metric"
                                      }
                                      onChange={this.handleRadioChange}
                                      color="primary"
                                    />
                                  }
                                  label="Metric"
                                />
                              </RadioGroup>
                            </FormControl>
                          </Grid>
                          {this.state.selectedRadioValue == "Imperial" ? (
                            <Grid container>
                              {" "}
                              <Grid item xs={12} sm={6}>
                                <TextField
                                  // onKeyDown={this.StopEnter}
                                  //id="remarks"
                                  name="Feet"
                                  label="Feet"
                                  style={{ width: "95%", height: "5%" }}
                                  className={classes.textFieldCard}
                                  onChange={this.feet}
                                  // margin="normal"
                                  // error={this.state.remarks}
                                  value={this.state.feet}
                                  //helperText={this.state.remarks_error}
                                  required={
                                    this.state.selectedRadioValue == "Imperial"
                                  }
                                />
                              </Grid>
                              <Grid item xs={12} sm={6}>
                                <TextField
                                  // onKeyDown={this.StopEnter}
                                  //id="remarks"
                                  name="inches"
                                  label="Inches"
                                  // className={classes.textFieldCard}
                                  onChange={this.inches}
                                  // margin="normal"
                                  // error={this.state.remarks}
                                  value={this.state.inches}
                                  required={
                                    this.state.selectedRadioValue == "Imperial"
                                  }
                                  //helperText={this.state.remarks_error}
                                  // required
                                  style={{ width: "95%", height: "5%" }}
                                />
                              </Grid>
                            </Grid>
                          ) : (
                            <Grid item xs={12} sm={12}>
                              <TextField
                                // onKeyDown={this.StopEnter}
                                //id="remarks"
                                name="meters"
                                label="Meters"
                                // className={classes.textFieldCard}
                                onChange={this.meters}
                                // margin="normal"
                                // error={this.state.remarks}
                                value={this.state.meters}
                                required={
                                  this.state.selectedRadioValue == "Metric"
                                }
                                //helperText={this.state.remarks_error}
                                // required
                                style={{ width: "100%", height: "5%" }}
                              />
                            </Grid>
                          )}
                        </Grid>
                      ) : (
                        <Grid container></Grid>
                      )}

                      {QuestionLists.type_id == 9 ? (
                        <Grid container>
                          <Grid item xs={12} align="left">
                            <FormControl component="fieldset">
                              <FormLabel component="legend">
                                {" "}
                                My measurement is in:
                              </FormLabel>
                              <RadioGroup
                                row
                                aria-label="position"
                                name="position"
                                defaultValue="top"
                              >
                                <FormControlLabel
                                  value="Metric"
                                  control={
                                    <Radio
                                      checked={
                                        this.state.selectedWeightRadioValue ==
                                        "Metric"
                                      }
                                      onChange={this.handleWeightRadioChange}
                                      color="primary"
                                    />
                                  }
                                  label="Metric"
                                />
                                <FormControlLabel
                                  value="Imperial"
                                  control={
                                    <Radio
                                      checked={
                                        this.state.selectedWeightRadioValue ==
                                        "Imperial"
                                      }
                                      onChange={this.handleWeightRadioChange}
                                      color="primary"
                                    />
                                  }
                                  label="Imperial"
                                />
                              </RadioGroup>
                            </FormControl>
                          </Grid>
                          {this.state.selectedWeightRadioValue == "Metric" ? (
                            <Grid item xs={12} sm={12}>
                              <TextField
                                // onKeyDown={this.StopEnter}
                                //id="remarks"
                                name="kilograms"
                                label="Kilograms"
                                style={{ width: "100%", height: "5%" }}
                                className={classes.textFieldCard}
                                onChange={this.kg}
                                // margin="normal"
                                // error={this.state.remarks}
                                value={this.state.kg}
                                //helperText={this.state.remarks_error}
                                required={
                                  this.state.selectedWeightRadioValue ==
                                  "Metric"
                                }
                              />
                            </Grid>
                          ) : (
                            <Grid item xs={12} sm={12}>
                              <TextField
                                // onKeyDown={this.StopEnter}
                                //id="remarks"
                                name="pounds"
                                label="Pounds"
                                // className={classes.textFieldCard}
                                onChange={this.pounds}
                                // margin="normal"
                                // error={this.state.remarks}
                                value={this.state.pounds}
                                required={
                                  this.state.selectedWeightRadioValue ==
                                  "Imperial"
                                }
                                //helperText={this.state.remarks_error}
                                // required
                                style={{ width: "100%", height: "5%" }}
                              />
                            </Grid>
                          )}
                        </Grid>
                      ) : (
                        <Grid container></Grid>
                      )}

                      {QuestionLists.type_id == 5 ? (
                        <Grid container>
                          {this.state.AnswerList.map((AnswerLists, idx) => (
                            <React.Fragment key={idx}>
                              <Grid item xs={12} align="left">
                                <Typography
                                  variant="title"
                                  style={{
                                    marginTop: "10px",
                                    fontSize: "18px",
                                    fontFamily: "initial",
                                  }}
                                >
                                  {AnswerLists.answer_choice}
                                </Typography>
                              </Grid>
                            </React.Fragment>
                          ))}
                        </Grid>
                      ) : (
                        <Grid container></Grid>
                      )}

                      {QuestionLists.type_id == 1 ? (
                        <Grid container>
                          {this.state.AnswerList.map((AnswerLists, idx) => (
                            <React.Fragment key={idx}>
                              <Grid item xs={12} align="left">
                                <FormControl component="fieldset">
                                  <RadioGroup
                                    aria-label="position"
                                    name="position"
                                    defaultValue="top"
                                  >
                                    <FormControlLabel
                                      value={AnswerLists.answer_value}
                                      control={
                                        <Radio
                                          checked={
                                            this.state.AnswerValue ==
                                            AnswerLists.answer_value
                                          }
                                          onChange={(event) =>
                                            this.handleAnswerRadioChange(
                                              event,
                                              AnswerLists.answer_value,
                                              AnswerLists.answer_id
                                            )
                                          }
                                          color="primary"
                                        />
                                      }
                                      label={AnswerLists.answer_choice}
                                    />
                                  </RadioGroup>
                                </FormControl>
                              </Grid>
                            </React.Fragment>
                          ))}
                        </Grid>
                      ) : (
                        <Grid container></Grid>
                      )}
                      {QuestionLists.type_id == 6 ? (
                        <Grid container>
                          {this.state.AnswerList.map((AnswerLists, idx) => (
                            <React.Fragment key={idx}>
                              <Grid item xs={12} align="left">
                                <FormControl component="fieldset">
                                  <RadioGroup
                                    aria-label="position"
                                    name="position"
                                    defaultValue="top"
                                  >
                                    <FormControlLabel
                                      value={AnswerLists.answer_value}
                                      control={
                                        <Radio
                                          checked={
                                            this.state
                                              .selectedAnswerRadioValue ==
                                            AnswerLists.answer_value
                                          }
                                          onChange={(event) =>
                                            this.handleAnswerRadioChange(
                                              event,
                                              AnswerLists.answer_value,
                                              AnswerLists.answer_id
                                            )
                                          }
                                          color="primary"
                                        />
                                      }
                                      label={AnswerLists.answer_choice}
                                    />
                                  </RadioGroup>
                                </FormControl>
                              </Grid>
                            </React.Fragment>
                          ))}
                        </Grid>
                      ) : (
                        <Grid container></Grid>
                      )}
                      <Grid
                        item
                        xs={12}
                        align="center"
                        direction="row"
                        justify="flex-start"
                        alignItems="flex-start"
                      >
                        <img
                          style={{ height: "250px" }}
                          src={QuestionLists.asset_name}
                        />
                      </Grid>
                    </Grid>
                  </React.Fragment>
                ))}

                <Grid item xs={12} style={{ height: "60px" }}></Grid>
              </CardContent>
            </Card>
          </div>
          <AppBar
            position="fixed"
            style={{ top: "auto", bottom: 0 }}
            color="default"
          >
            <Toolbar variant="dense">
              {this.state.QuestionIndex > 3 ? (
                <Button
                  variant="contained"
                  color="default"
                  onClick={(event) => this.BackForm(event)}
                  style={{ marginRight: "10px" }}
                >
                  <SkipPreviousIcon style={{ marginRight: "1px" }} />
                  Previous
                </Button>
              ) : (
                <Grid></Grid>
              )}

              <div className={classes.grow} />
              <ProgressBar
                width="400px"
                height="16px"
                rect
                fontColor="gray"
                percentage="10"
                rectPadding="1px"
                rectBorderRadius="20px"
                trackPathColor="transparent"
                bgColor="primary"
                trackBorderColor="grey"
                defColor={{
                  fair: "teal",
                  good: "teal",
                  excellent: "teal",
                  poor: "teal",
                }}
              />
              <div className={classes.grow} />
              <Button
                variant="contained"
                color="default"
                onClick={(event) => this.NextForm(event)}
                style={{ marginRight: "10px" }}
              >
                <SkipNextIcon style={{ marginRight: "1px" }} />
                Skip
              </Button>

              <Button
                variant="contained"
                color="primary"
                onClick={(event) => this.NextForm(event)}
              >
                <DoneIcon style={{ marginRight: "1px" }} />
                Next
              </Button>
            </Toolbar>
          </AppBar>
        </form>
      </div>
    );
  }
}

export default withStyles(useStyles)(Survey);
